from setuptools import setup


setup(name='fixer_demo',
      version='0.2',
      description='Fixer service demo package',
      url='',
      author='erfan',
      author_email='tajdarerfan83@gmail.com',
      license='MIT',
      packages=['fixer'],
      install_requires=['requests'],
      zip_safe=False)